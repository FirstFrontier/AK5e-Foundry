# Codex Migration Report

Source: /home/patch/.codex
Target: /home/patch/.openclaw/workspace
Backup: /home/patch/AK5e-Foundry/2026-11-01T05-19-50.463+00-00-openclaw-backup.tar.gz

Migrated: 4
Skipped: 0
Conflicts: 0
Errors: 2

- migrated: auth:openai
- migrated: auth:openai:config:auth
- migrated: auth:openai:config:agents-defaults
- warning: plugin:openai-templates (plugin_inventory_unavailable)
- warning: plugin:plugin-management (plugin_inventory_unavailable)
- error: plugin:sites (refresh_failed)
- error: plugin:work-pets (refresh_failed)
- warning: config:codex-plugins (selected Codex plugin activation is incomplete)
- migrated: archive:config.toml
